

$(function () {
    $("#datepicker").datepicker({
        showOn: "button",
        buttonImage: "img/calendar-icon.png",
        buttonImageOnly: true,
        buttonText: "Select date",
        dateFormat: "mm/dd/yy"

    });
});

// Lay ngay mac dinh
$(document).ready(function () {
    var d = new Date();

    var month = d.getMonth() + 1;
    var day = d.getDate();

    var output = (('' + month).length < 2 * '' ) + month + '/' +
        (('' + day).length < 2 * 1) + day + '/' +
        d.getFullYear();
    $('#datepicker').val(output);
});



// 1. In ra table danh sách nhân viên

$(document).ready(function () {
  let employeeList = [];

//chọn ngày
  $("#datepicker").datepicker({
    dateFormat: "mm/dd/yyyy"
  });

  // nhân viên
  function Employee(tk, name, email, password, ngayLam, luongCB, chucVu, gioLam) {
    this.taiKhoan = tk;
    this.hoTen = name;
    this.email = email;
    this.matKhau = password;
    this.ngayLam = ngayLam;
    this.luongCB = luongCB;
    this.chucVu = chucVu;
    this.gioLam = gioLam;
    this.tongLuong = this.calculateluongCB(luongCB, chucVu);
    this.loaiNhanVien = chucVu; 
    this.classification = this.classifyEmployee(gioLam); 
  }

  // Tính tổng lương 
  Employee.prototype.calculateluongCB = function (luongCB, chucVu) {
    switch (chucVu) {
      case "Giám đốc":
        return luongCB * 3;
      case "Trưởng phòng":
        return luongCB * 2;
      case "Nhân viên":
        return luongCB;
      default:
        return luongCB;
    }
  };

  // xep loai nv
  Employee.prototype.classifyEmployee = function (gioLam) {
    if (gioLam >= 192) {
      return "Xuất sắc";
    } else if (gioLam>= 176) {
      return "Giỏi";
    } else if (gioLam >= 160) {
      return "Khá";
    } else {
      return "Trung bình";
    }
  };

  
  function displayEmployeeList() {
    let tableBody = $("#tableDanhSach");
    tableBody.empty(); 

    employeeList.forEach((emp, index) => {
      let nv = `
        <tr>
          <td>${emp.taiKhoan}</td>
          <td>${emp.hoTen}</td>
          <td>${emp.email}</td>
          <td>${emp.ngayLam}</td>
          <td>${emp.chucVu}</td>
          <td>${emp.tongLuong}</td>
          <td>${emp.classification}</td>
          <td>
            <button class="btn btn-warning" onclick="editEmployee(${index})">Sửa</button>
            <button class="btn btn-danger" onclick="deleteEmployee(${index})">Xóa</button>
          </td>
        </tr>
      `;
      tableBody.append(nv);
    });
  }

  // Thêm một nv mới
  $("#btnThemNV").click(function (e) {
    e.preventDefault();
    

    let valid = true; 

    //các giá trị 
    let tk = $("#tknv").val();
    let name = $("#name").val();
    let email = $("#email").val();
    let password = $("#password").val();
    let datepicker= $("#datepicker").val();
    let luongCB = parseFloat($("#luongCB").val());
    let chucvu = $("#chucvu").val();
    let gioLam = parseInt($("#gioLam").val());


    if (valid) {
      //Tạo một đối tượng nv mới
      let newEmployee = new Employee(tk, name, email, password, datepicker, luongCB, chucvu, gioLam);

    
      employeeList.push(newEmployee);
      displayEmployeeList();

      $("#myModal").modal('hide');
      $("form")[0].reset();
    }
  });


  window.editEmployee = function (index) {
    let nv = employeeList[index];
    
    //thong tin
    $("#tknv").val(employe.taiKhoan);
    $("#name").val(nv.hoTen);
    $("#email").val(nv.email);
    $("#password").val(nv.matKhau);
    $("#datepicker").val(nv.ngayLam);
    $("#luongCB").val(nv.luongCB);
    $("#chucvu").val(nv.chucVu);
    $("#gioLam").val(nv.gioLam);

   // Cập nhật nv khi nút cập nhật nhấp vào
    $("#btnCapNhat").click(function () {
      // Validate the updated inputs
      let tknv = $("#tknv").val();
      let name = $("#name").val();
      let email = $("#email").val();
      let password = $("#password").val();
      let datepicker = $("#datepicker").val();
      let luongCB = parseFloat($("#luongCB").val());
      let chucVu = $("#chucvu").val();
      let gioLam = parseInt($("#gioLam").val());

      if (valid) {
        
        //Cập nhật nv
        let updatedEmployee = new Employee(tknv, name, email, password, datepicker, luongCB, chucVu, gioLam);

        // // Thay thế đối tượng nv cũ trong danh sách
        employeeList[index] = updatedEmployee;

        // Hiển thị danh sách nv đã cập nhật
        displayEmployeeList();

        
        $("#myModal").modal('hide');
      }
    });
  };

  // xóa nv
  window.deleteEmployee = function (index) {
    employeeList.splice(index, 1); 
    displayEmployeeList(); 
  };

  //Xuất sắc, Giỏi, Khá, Trung bình
  $("#searchClassification").change(function () {
    let selectedClass = $(this).val();
    let filteredList = employeeList.filter(function (emp) {
      return emp.classification === selectedClass || selectedClass === "all";
    });
    
    displayFilteredList(filteredList);
  });

  //Hiển thị danh sách nv 
  function displayFilteredList(list) {
    let tableBody = $("#tableDanhSach");
    tableBody.empty();

    list.forEach((emp, index) => {
      let nv = `
        <tr>
          <td>${emp.taiKhoan}</td>
          <td>${emp.hoTen}</td>
          <td>${emp.email}</td>
          <td>${emp.ngayLam}</td>
          <td>${emp.chucVu}</td>
          <td>${emp.tongLuong}</td>
          <td>${emp.classification}</td>
          <td>
            <button class="btn btn-warning" onclick="editEmployee(${index})">Sửa</button>
            <button class="btn btn-danger" onclick="deleteEmployee(${index})">Xóa</button>
          </td>
        </tr>
      `;
      tableBody.append(nv);
    });
  }

});
